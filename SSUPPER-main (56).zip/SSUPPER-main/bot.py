# -*- coding: utf-8 -*-
"""
🎮 O'yin Sirlari — Free Fire Telegram bot
Asosiy ishga tushirish fayli.
"""

import logging
import random
import re

from telegram import Update, MenuButtonDefault, ReactionTypeEmoji, ReplyKeyboardRemove
from telegram.error import TelegramError
from telegram.ext import (
    Application,
    ApplicationHandlerStop,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    ContextTypes,
    filters,
)

import database as db
from config import BOT_TOKEN, ADMIN_ID
from keyboards import (
    main_menu_keyboard,
    admin_panel_keyboard,
    MENU_VERSION,
    BTN_SETTINGS,
    BTN_NICKS,
    BTN_TABLET,
    BTN_HACK,
    BTN_CUSTOM,
    BTN_WEBSITE,
    BTN_NEWS,
    BTN_MUSIC,
    BTN_QUIZ,
    BTN_DIAMONDS,
    BTN_ACCOUNT,
    BTN_HELP,
    BTN_GUIDES,
    BTN_FAQ,
    BTN_STATS,
    BTN_BROADCAST,
    BTN_EDIT_TEXTS,
    BTN_FORCE_SUB,
    BTN_MIN_WITHDRAW,
    BTN_BLOCKED_USERS,
    BTN_ADMIN_CREDIT,
    BTN_WITHDRAW,
    BTN_GIFT_ALL,
    BTN_DEDUCT_DIAMOND,
    BTN_DEDUCT_ALL_DIAMONDS,
    BTN_TOP_REFRESH,
    BTN_ABOUT_USER,
    BTN_FF2017,
    BTN_MAIN_FF,
    BTN_MAIN_DIAMONDS,
    BTN_MAIN_SERVICES,
    BTN_MAIN_PROFILE,
    BTN_M2_DIAMONDS,
    BTN_M2_SERVICES,
    BTN_M2_SETTINGS,
    BTN_M2_NICKS,
    BTN_M2_PAYMENTS,
    BTN_GIFTS,
    BTN_MAIN_RASM,
    BTN_MAIN_VIDEO,
    BTN_MAIN_MUSIC,
    BTN_MINI_GAMES,
    BTN_MY_ACCOUNT,
    BTN_STORE,
    BTN_GIFT_ORDER,
    BTN_WITHDRAW_WIN,
    BTN_PRO_SUB,
    BTN_ORDERS_CHANNEL,
    BTN_BACK,
    BTN_PORTAL,
    BTN_FF_ADMIN_PANEL,
    BTN_NASTROYKA_ADD,
    orders_channel_keyboard,
    subscription_keyboard,
)

from handlers.pro_sub import on_pro_sub_button, on_prosub_buy
from handlers.pro_section import (
    on_prosec_back,
    on_prosec_brazilian,
    cancel_pro_brazilian,
    receive_pro_brazilian_model,
    on_prosec_superik,
    on_prosec_sirli,
    on_prosec_mukofot,
    on_prosec_aivideo,
    cancel_pro_aivideo,
    receive_pro_video_prompt,
    on_prosec_airasm,
    cancel_pro_airasm,
    receive_pro_rasm_prompt,
    WAITING_PRO_BRAZIL_MODEL,
    WAITING_PRO_VIDEO_PROMPT,
    WAITING_PRO_RASM_PROMPT,
)

from handlers.start import (
    start_command,
    check_subscription_callback,
    on_player_type_selected,
    on_language_selected,
    subscribe_text,
    on_start_account_callback,
    on_start_services_callback,
    on_start_back_callback,
    on_all_services_item,
    on_video_button_from_services,
)
from handlers.subscription import get_unsubscribed_channels
from handlers.gifts import (
    on_gifts_button,
    on_gift_free_diamond,
    on_gift_money_bonus,
    on_gift_diamond_bonus,
)
from handlers.top_users import (
    on_top_users_button,
    on_top_users_tab,
    on_top_refresh_button,
)
from handlers.menu import (
    haqida_command,
    menu_command,
    update_command,
    profil_command,
    yordam_command,
    yangiliklar_command,
    saytimiz_command,
    on_help_button,
    on_settings_button,
    on_nicks_button,
    on_guides_button,
    on_website_button,
    on_news_button,
    on_music_button,
    on_ff2017_button,
    on_gotomainmenu_callback,
)
from handlers.headshot_pro import (
    on_hspro_intro,
    on_hspro_prices,
    on_hspro_buy,
    on_hspro_pay_method,
    on_hspro_done,
    receive_hspro_amount,
    receive_hspro_receipt,
    cancel_hspro,
    hspro_approved,
    hspro_rejected,
    on_hspro_get_settings_start,
    receive_hspro_phone_model,
    cancel_hspro_get_settings,
    WAITING_HSPRO_PHONE_MODEL,
    WAITING_HSPRO_AMOUNT,
    WAITING_HSPRO_RECEIPT,
)
from handlers.almaz_ishlash import (
    on_almaz_menu,
    on_almaz_games,
    on_almaz_page1,
    on_almaz_page2,
    on_almaz_dashboard,
    on_almaz_account,
    check_referral_penalties_job,
    on_almaz_withdraw_account,
    on_almaz_withdraw_start,
    on_almaz_withdraw_refcheck,
    on_almaz_withdraw_reply_button,
    receive_almazwd_ff_id,
    receive_almazwd_amount,
    on_almaz_withdraw_cancel_callback,
    cancel_almazwd,
    WAITING_ALMAZWD_FF_ID,
    WAITING_ALMAZWD_AMOUNT,
)
from handlers.settings import on_brand_selected, on_back_to_brands, on_model_selected
from handlers.tablet import (
    on_tablet_button,
    on_tablet_brand_selected,
    on_back_to_tablet_brands,
    on_tablet_model_selected,
)
from handlers.nicknames import on_nick_category, on_back_to_nicks
from handlers.guides import on_guide_selected, on_back_to_guides
from handlers.hack import (
    on_hack_button,
    on_hack_back,
    on_hack_proxy,
    on_hack_cheat,
    on_hack_ffid,
    receive_ff_id,
    cancel_ffid,
    WAITING_FF_ID,
)
from handlers.faq import (
    start_faq,
    start_faq_from_callback,
    receive_faq_question,
    cancel_faq,
    start_faq_admin_reply,
    receive_faq_admin_reply,
    cancel_faq_admin_reply,
    WAITING_FAQ_QUESTION,
    WAITING_FAQ_ADMIN_REPLY,
)
from handlers.quiz import on_quiz_button, on_quiz_button_callback, on_quiz_answer, on_quiz_begin
from handlers.custom import (
    on_custom_button,
    on_custom_back,
    on_custom_free,
    cancel_free,
    receive_free_model,
    on_custom_paid,
    on_paid_tier_selected,
    on_paid_buy_clicked,
    on_paid_agree,
    cancel_paid,
    receive_paid_model,
    start_custom_admin_reply,
    receive_custom_admin_reply,
    cancel_custom_admin_reply,
    WAITING_FREE_MODEL,
    WAITING_PAID_MODEL,
    WAITING_CUSTOM_ADMIN_REPLY,
)
from handlers.diamonds import (
    on_diamonds_button,
    on_diamonds_admin,
    on_diamonds_bot,
    on_diamonds_back,
    on_package_selected,
    start_buy,
    receive_order_ff_id,
    cancel_order,
    order_sent_by_admin,
    go_to_account_hint,
    on_account_button,
    on_account_admin,
    on_account_card,
    on_account_bonus,
    on_account_back,
    start_topup_paid,
    receive_topup_amount,
    receive_topup_receipt,
    cancel_topup,
    topup_approved,
    topup_rejected,
    WAITING_ORDER_FF_ID,
    WAITING_TOPUP_AMOUNT,
    WAITING_TOPUP_RECEIPT,
)
from handlers.admin import (
    on_stats_button,
    start_broadcast,
    on_broadcast_type_chosen,
    send_broadcast,
    cancel_broadcast,
    receive_broadcast_inline_content,
    receive_broadcast_button_text,
    receive_broadcast_button_url,
    WAITING_BROADCAST,
    WAITING_BROADCAST_CHOICE,
    WAITING_BROADCAST_INLINE_CONTENT,
    WAITING_BROADCAST_BTN_TEXT,
    WAITING_BROADCAST_BTN_URL,
    start_edit_texts,
    choose_text_to_edit,
    receive_new_text,
    cancel_edit_text,
    WAITING_EDIT_TEXT,
    on_ff_admin_panel_button,
    on_ff_admin_panel_refresh,
    on_ff_admin_close,
    on_ff_admin_tour_open,
    on_ff_admin_tour_add_start,
    receive_fftour_content,
    skip_fftour_channel,
    receive_fftour_channel,
    cancel_fftour,
    on_ff_admin_tour_delete,
    on_ff_admin_acc_open,
    on_ff_admin_acc_add_start,
    receive_ffacc_content,
    receive_ffacc_link,
    cancel_ffacc,
    on_ff_admin_acc_delete,
    WAITING_FFTOUR_CONTENT,
    WAITING_FFTOUR_CHANNEL,
    WAITING_FFACC_CONTENT,
    WAITING_FFACC_LINK,
    on_nastroyka_admin_start,
    on_nastroyka_admin_close,
    on_nastroyka_admin_brand,
    on_nastroyka_admin_back_brands,
    on_nastroyka_admin_model,
    on_nastroyka_admin_back_models,
    on_nastroyka_admin_delete,
    on_nastroyka_type_selected,
    receive_nastroyka_content,
    cancel_nastroyka,
    WAITING_NASTROYKA_CONTENT,
    on_turniradmin_add_start,
    receive_turnir_day,
    receive_turnir_title,
    receive_turnir_format,
    receive_turnir_time,
    receive_turnir_note,
    skip_turnir_note,
    cancel_turnir_add,
    on_turniradmin_delete,
    WAITING_TURNIR_DAY,
    WAITING_TURNIR_TITLE,
    WAITING_TURNIR_FORMAT,
    WAITING_TURNIR_TIME,
    WAITING_TURNIR_NOTE,
    start_force_sub,
    on_force_sub_remove,
    start_force_sub_add,
    receive_force_sub_channel,
    cancel_force_sub_add,
    on_force_sub_close,
    WAITING_FORCE_SUB_CHANNEL,
    start_min_withdraw,
    receive_min_withdraw_value,
    cancel_min_withdraw,
    WAITING_MIN_WITHDRAW,
    on_about_user_button,
    receive_about_user_id,
    cancel_about_user,
    WAITING_ABOUT_USER,
)
from handlers.turnirlar import (
    on_turnirlar_button,
    on_turnir_open,
    on_turnir_nav,
    on_turnir_back_list,
)
from handlers.nimagap import (
    on_nimagap_open,
    on_nimagap_tournaments_menu,
    on_nimagap_accounts,
    on_fftour_slot_detail,
)
from handlers.blocked_users import (
    on_blocked_users_button,
    on_blocked_callback,
)
from handlers.admin_credit import (
    on_admin_credit_button,
    on_credit_type_selected,
    receive_credit_amount,
    receive_credit_user_id,
    receive_block_user_id,
    cancel_credit,
    WAITING_CREDIT_AMOUNT,
    WAITING_CREDIT_USER_ID,
    WAITING_BLOCK_USER_ID,
    on_gift_all_button,
    on_gift_type_selected,
    receive_gift_amount,
    on_gift_all_confirm,
    on_gift_all_cancel,
    WAITING_GIFT_AMOUNT,
    on_deduct_diamond_button,
    receive_deduct_username,
    receive_deduct_amount,
    cancel_deduct,
    WAITING_DEDUCT_USERNAME,
    WAITING_DEDUCT_AMOUNT,
    on_deduct_all_diamonds_button,
    on_deduct_all_diamonds_confirm,
)
from handlers.withdraw import (
    on_withdraw_sent_by_admin,
)
from handlers.image_gen import (
    on_rasm_button,
    on_rasm_back,
    on_oddiy_rasm_start,
    cancel_oddiy,
    receive_oddiy_text,
    on_oddiy_style_selected,
    on_maxsus_rasm_start,
    cancel_maxsus,
    receive_maxsus_name,
    receive_maxsus_desc,
    WAITING_ODDIY_TEXT,
    WAITING_MAXSUS_NAME,
    WAITING_MAXSUS_DESC,
)
from handlers.video_gen import (
    on_video_button,
    on_video_cancel_inline,
    cancel_video,
    receive_video_prompt,
    WAITING_VIDEO_PROMPT,
)
from handlers.music_gen import (
    on_music_create_button,
    on_music_cancel,
    on_music_genre_selected,
    cancel_music_prompt,
    receive_music_prompt,
    on_music_back_to_genre,
    on_music_lang_selected,
    on_music_back_to_lang,
    on_music_prepare,
    start_music_admin_reply,
    cancel_music_admin_reply,
    receive_music_admin_reply,
    WAITING_MUSIC_PROMPT,
    WAITING_MUSIC_ADMIN_REPLY,
)
from handlers.games import (
    receive_number_guess,
    on_my_account_button,
    on_myacc_pay_button,
)
# 🎮 Mini O'yinlar - qiyin darajadagi 10 ta Free Fire o'yini (yangi oqim)
from handlers.hard_games import (
    on_games_button,
    on_games_root_callback as on_hard_games_root_callback,
)
# 🟢 Oson O'yinlar - 20 ta yengil daraja o'yini (+3 💎 / −3 💎)
from handlers.easy_games import on_easy_games_callback
# 💣 Portlovchi almaz - tavakkal o'yinlari (±180 💎, ogohlantirish + rozilik bilan)
from handlers.risk_games import on_risk_games_callback

# ---------- Yangi bosh menyu bo'limlari (🎮 Free Fire / 💎 Almaz olish / 🛠️ Xizmatlar / 👤 Profil) ----------
from handlers.ffmenu import (
    on_ff_main_button,
    on_back_to_ff,
    on_ff_phone,
    on_ff_tablet,
    on_ff_pc,
)
from handlers.pc import on_pc_model_selected, on_back_to_pc
from handlers.nickgen import (
    start_nick_creation,
    receive_nick_name,
    cancel_nick_creation,
    back_to_start_from_nick,
    WAITING_NICK_NAME,
)
from handlers.services import (
    on_services_button,
    on_back_to_services,
    on_svc_bonus,
    on_svc_pay,
    on_svc_guides,
    on_svc_news,
    on_svc_other,
    on_back_to_services_other,
    on_svcother_help,
    on_svcother_website,
    on_svcother_music,
    on_svcother_hack,
    on_svcother_custom,
    on_svcother_ff2017,
)
from handlers.profile import on_profile_button, on_profile_account

# ---------- 🆕 Yangi asosiy menyu (6 tugma, 2 ustunda) ----------
from handlers.newflow import (
    on_m2_diamonds_button,
    on_diaget_free,
    on_diaget_buy,
    on_m2_settings_button,
    on_newset_back,
    on_newset_premium,
    on_m2_nicks_button,
    on_newnick_back,
    on_newnick_category,
    on_m2_services_button,
    on_newsvc_back,
    on_newsvc_item,
    on_m2_payments_button,
    on_pay_back,
    on_pay_admin,
    on_pay_card,
)

# ---------- 🛒 Free Fire Do'koni ----------
from handlers.store import (
    on_store_button,
    on_store_back,
    on_store_item_selected,
    start_store_buy,
    receive_store_ff_id,
    cancel_store_order,
    store_order_sent_by_admin,
    WAITING_STORE_FF_ID,
)

# ---------- 🎁 Giftlar (o'yin ichidagi gift buyurtmalari) ----------
from handlers.gift_order import (
    on_gift_order_button,
    on_gift_order_back,
    on_gift_order_type_selected,
    receive_gift_order_item,
    cancel_gift_order,
    start_gift_order_admin_reply,
    receive_gift_order_admin_reply,
    cancel_gift_order_admin_reply,
    WAITING_GIFT_ORDER_ITEM,
    WAITING_GIFT_ORDER_ADMIN_REPLY,
)

# ---------- 🏆 Yutiqni chiqarish ----------
from handlers.withdraw_win import (
    on_withdraw_win_button,
    on_withdraw_win_back,
    on_withdraw_win_cash_noop,
    on_withdraw_win_cash,
    receive_withdraw_cash_amount,
    cancel_withdraw_cash,
    WAITING_WITHDRAW_CASH_AMOUNT,
)

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


_LEADING_EMOJI_RE = re.compile(
    r"^([\U0001F000-\U0001FFFF\u2600-\u27BF\u2B00-\u2BFF]\uFE0F?)\s*"
)


def _exact(text: str):
    # Pastki (Reply) tugmalarga premium custom emoji ikonkasi qo'yilganda,
    # tugma matnidan boshidagi native emoji olib tashlanadi (keyboards.py
    # ichidagi _kb/_apply_emoji_icon). Shu sababli bu yerda ham emoji
    # bor ("🔙 Orqaga") ham yo'q ("Orqaga") holatlarning ikkalasi ham mos
    # kelishi uchun boshidagi emoji ixtiyoriy qilib belgilanadi.
    match = _LEADING_EMOJI_RE.match(text)
    if match:
        emoji = re.escape(match.group(1))
        rest = re.escape(text[match.end():])
        pattern = f"^(?:{emoji}\\s*)?{rest}$"
    else:
        pattern = f"^{re.escape(text)}$"
    return filters.Regex(pattern)


# Barcha pastki (reply) menyu tugmalari matni - admin kutilayotgan
# suhbat (masalan "rasm/nastroyka yuboring") ichida bo'lganda, agar u
# tasodifan boshqa bir menyu tugmasini bossa, bot buni "javob matni"
# sifatida noto'g'ri yubormasligi uchun ishlatiladi.
_ALL_MENU_BUTTON_TEXTS = [
    BTN_SETTINGS, BTN_TABLET, BTN_NICKS, BTN_HACK, BTN_CUSTOM, BTN_WEBSITE,
    BTN_NEWS, BTN_MUSIC, BTN_QUIZ, BTN_DIAMONDS, BTN_ACCOUNT, BTN_HELP,
    BTN_GUIDES, BTN_FAQ, BTN_STATS, BTN_BROADCAST, BTN_EDIT_TEXTS,
    BTN_FORCE_SUB, BTN_MIN_WITHDRAW, BTN_BLOCKED_USERS,
    BTN_ADMIN_CREDIT, BTN_WITHDRAW, BTN_GIFT_ALL, BTN_DEDUCT_DIAMOND,
    BTN_DEDUCT_ALL_DIAMONDS, BTN_TOP_REFRESH, BTN_ABOUT_USER,
    BTN_FF2017, BTN_MAIN_FF, BTN_MAIN_DIAMONDS, BTN_MAIN_SERVICES,
    BTN_MAIN_PROFILE, BTN_M2_DIAMONDS, BTN_M2_SERVICES, BTN_M2_SETTINGS,
    BTN_M2_NICKS, BTN_M2_PAYMENTS, BTN_GIFTS, BTN_MAIN_RASM, BTN_MAIN_VIDEO,
    BTN_MAIN_MUSIC, BTN_MINI_GAMES, BTN_MY_ACCOUNT, BTN_STORE,
    BTN_GIFT_ORDER, BTN_WITHDRAW_WIN, BTN_PRO_SUB, BTN_ORDERS_CHANNEL,
    BTN_BACK, BTN_PORTAL,
]


def _any_menu_button_filter():
    combined = None
    for text in dict.fromkeys(_ALL_MENU_BUTTON_TEXTS):  # noyob qilib
        f = _exact(text)
        combined = f if combined is None else (combined | f)
    return combined


async def on_stray_menu_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Admin kutilayotgan suhbat (rasm/video/nastroyka yuborish va h.k.)
    ichida bo'lsa-yu, tasodifan boshqa menyu tugmasini bossa: suhbatni
    xavfsiz bekor qilamiz va bosilgan tugmani DARHOL, qaytadan bosishga
    hojat qoldirmay normal ishlaydigan qilib qayta yuboramiz - bot
    "yangilanganday" bo'ladi."""
    context.user_data.pop("custom_target_uid", None)
    context.user_data.pop("custom_target_kind", None)
    await context.application.process_update(update)
    return ConversationHandler.END


async def admin_panel_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/admin - faqat ADMIN_ID uchun: eski admin panel tugmalarini
    (Statistika, Admin buyrug'i, Xabar yuborish, Nastroyka qo'shish,
    Turnir boshqaruvi va h.k.) pastki menyu sifatida ochadi."""
    user = update.effective_user
    if not user or user.id != ADMIN_ID:
        return
    await update.message.reply_text(
        "🛠 <b>Admin paneli</b>\n\nKerakli bo'limni tanlang 👇",
        parse_mode="HTML",
        reply_markup=admin_panel_keyboard(),
    )


async def on_back_to_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """🔙 Orqaga - istalgan ichki bo'limdan bosh menyuga qaytaradi."""
    user = update.effective_user
    is_admin = user.id == ADMIN_ID
    await update.message.reply_text(
        "🏠 Bosh menyu", reply_markup=main_menu_keyboard(is_admin)
    )


async def on_orders_channel_button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """📢 Buyurtmalar - foydalanuvchini bajarilgan buyurtmalar kanaliga yo'naltiradi."""
    await update.message.reply_text(
        "📢 <b>Buyurtmalar</b>\n\n"
        "Bajarilgan barcha buyurtmalar shu kanalda e'lon qilinadi. "
        "Kanalga o'tish uchun pastdagi tugmani bosing 👇",
        parse_mode="HTML",
        reply_markup=orders_channel_keyboard(),
    )


# Botga yozilgan har bir xabarga shu emojilardan biri TASODIFIY tanlanib
# reaksiya sifatida qo'yiladi (🔥 olovcha, 🐬 delfin yoki ❤️ yurakcha).
AUTO_REACTION_EMOJIS = ("🔥", "🐬", "❤️")


async def _auto_refresh_menu_if_needed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Foydalanuvchining pastki (Reply) tugmalar oynasi eskirgan bo'lsa
    (ya'ni oxirgi marta ko'rgan menyusi joriy MENU_VERSION'dan past bo'lsa),
    hech qanday buyruq yubormasa ham, botga yozgan birinchi xabaridayoq
    avtomatik ravishda eski oynani tozalab, yangi menyuni ko'rsatadi."""
    user = update.effective_user
    chat = update.effective_chat
    if not user or not chat:
        return

    current_version = db.get_menu_version(user.id)
    if current_version >= MENU_VERSION:
        return

    is_admin = user.id == ADMIN_ID
    try:
        old = await context.bot.send_message(
            chat_id=chat.id, text="🔄 Yangilanmoqda...", reply_markup=ReplyKeyboardRemove()
        )
        try:
            await old.delete()
        except TelegramError:
            pass
        await context.bot.send_message(
            chat_id=chat.id,
            text="✅ <b>Bot yangilandi!</b>\n\nYangi tugmalar qo'shildi 👇",
            parse_mode="HTML",
            reply_markup=main_menu_keyboard(is_admin),
        )
        db.set_menu_version(user.id, MENU_VERSION)
    except TelegramError:
        pass


# Callback query'lar shu prefikslardan biri bilan boshlansa, majburiy obuna
# tekshiruvidan chetlab o'tiladi - chunki bularning o'zi til tanlash yoki
# obunani tekshirish jarayonining bir qismi.
SUBSCRIPTION_EXEMPT_CALLBACK_PREFIXES = ("lang:", "check_sub", "player:")


async def enforce_block_gate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Har qanday xabar yoki tugma bosilishidan ENG OLDIN ishlaydi.

    Agar foydalanuvchi admin tomonidan bloklangan bo'lsa - hech qanday
    tugma yoki xabar ishlamaydi, faqat "bloklangansiz" degan xabar
    ko'rsatiladi. Admin bloklashdan mustasno.
    """
    user = update.effective_user
    if not user or user.id == ADMIN_ID:
        return

    if not db.is_user_blocked(user.id):
        return

    query = update.callback_query
    block_text = "🚫 Siz botdan bloklangansiz. Admin bilan bog'laning."
    if query is not None:
        try:
            await query.answer(block_text, show_alert=True)
        except TelegramError:
            pass
    else:
        target = update.effective_message
        if target is not None:
            try:
                await target.reply_text(block_text)
            except TelegramError:
                pass

    # Bloklangan foydalanuvchi uchun boshqa hech qaysi handler ishlamasin.
    raise ApplicationHandlerStop


async def enforce_subscription_gate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Har qanday tugma (reply yoki inline) bosilishidan OLDIN ishlaydi.

    Agar foydalanuvchi majburiy kanallarga obuna bo'lmagan bo'lsa - HECH
    QAYSI tugma ishlamaydi, faqat obuna bo'lish taklifi ko'rsatiladi.
    Obuna bo'lgandan keyin barcha tugmalar odatdagidek ishlay boshlaydi.
    """
    user = update.effective_user
    if not user:
        return

    # Admin majburiy obunadan mustasno - botni boshqarishi kerak.
    if user.id == ADMIN_ID:
        return

    # /start buyrug'i har doim ishlaydi - u o'zi til tanlash va obuna
    # oqimini boshqaradi.
    if update.message is not None:
        text = update.message.text or ""
        if text.startswith("/start"):
            return

    query = update.callback_query
    if query is not None:
        data = query.data or ""
        if any(data.startswith(p) for p in SUBSCRIPTION_EXEMPT_CALLBACK_PREFIXES):
            return

    unsubscribed = await get_unsubscribed_channels(user.id, context)
    if not unsubscribed:
        return

    lang = db.get_user_language(user.id) or "uz"

    if query is not None:
        alert_text = (
            "⛔️ Бот пока не работает! Сначала подпишитесь на все каналы."
            if lang == "ru"
            else "⛔️ Bot hali ishlamaydi! Avval barcha kanallarga obuna bo'ling."
        )
        try:
            await query.answer(alert_text, show_alert=True)
        except TelegramError:
            pass
    else:
        target = update.effective_message
        if target is not None:
            try:
                await target.reply_text(
                    subscribe_text(lang),
                    parse_mode="HTML",
                    reply_markup=subscription_keyboard(),
                )
            except TelegramError:
                pass

    # Boshqa hech qaysi handler (shu jumladan boshqa guruhlardagilar ham)
    # ishlamasin - foydalanuvchi obuna bo'lmaguncha.
    raise ApplicationHandlerStop


async def log_all_messages(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user:
        db.touch_user_activity(update.effective_user.id)
        db.log_message(update.effective_user.id)
        await _auto_refresh_menu_if_needed(update, context)

    # Botga yozilgan har qanday xabarga (shu jumladan /start) avtomatik
    # reaksiya bosiladi.
    if update.effective_message and update.effective_chat:
        try:
            await context.bot.set_message_reaction(
                chat_id=update.effective_chat.id,
                message_id=update.effective_message.message_id,
                reaction=[ReactionTypeEmoji(emoji=random.choice(AUTO_REACTION_EMOJIS))],
            )
        except TelegramError:
            pass


async def log_all_callbacks(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Har qanday INLINE tugma bosilganda ham (matnli xabar yubormasa ham)
    foydalanuvchining pastki tugmalar oynasi eskirgan bo'lsa - avtomatik
    yangilanadi. Bu handler asosiy handlerlardan KEYIN (group=1) ishga
    tushadi, shu sabab inline tugmaning o'z funksiyasiga xalaqit bermaydi."""
    if update.effective_user:
        db.touch_user_activity(update.effective_user.id)
        await _auto_refresh_menu_if_needed(update, context)


async def on_error(update, context: ContextTypes.DEFAULT_TYPE):
    """Har qanday kutilmagan xatolikni to'liq holda LOGGA yozib qo'yadi -
    shunday qilib kelajakda biror joy jim qulab tushsa, sabab darhol
    ko'rinadi (konsol/loglarda)."""
    logger.exception("Ushlanmagan xatolik yuz berdi:", exc_info=context.error)


async def refresh_leaderboard_job(context: ContextTypes.DEFAULT_TYPE):
    """Har kuni (JobQueue orqali) 🏆 Top foydalanuvchilar reytingini
    (referallar va almazlar bo'yicha) qayta hisoblab, keshni yangilaydi."""
    db.refresh_leaderboard_cache()


async def post_init(application: Application):
    try:
        await application.bot.set_my_commands([])
        await application.bot.set_chat_menu_button(menu_button=MenuButtonDefault())
    except Exception:
        pass


def build_application() -> Application:
    db.init_db()
    app = Application.builder().token(BOT_TOKEN).post_init(post_init).build()
    app.add_error_handler(on_error)

    # ---------- ⚠️ Referal jarima tizimi (davriy tekshiruv) ----------
    # Har 30 daqiqada mukofot berilgan referallarni tekshirib, agar do'st
    # 1-2 kun ichida majburiy kanallardan chiqib ketgan bo'lsa jarima
    # qo'llaydi. JobQueue faqat "python-telegram-bot[job-queue]" (APScheduler)
    # o'rnatilgan bo'lsa ishlaydi - aks holda shu bo'lim jimgina o'tkazib
    # yuboriladi (botning qolgan qismi ishlashda davom etadi).
    if app.job_queue is not None:
        app.job_queue.run_repeating(
            check_referral_penalties_job, interval=1800, first=60
        )
    else:
        logging.warning(
            "JobQueue mavjud emas - 'pip install python-telegram-bot[job-queue]' "
            "o'rnatilmaguncha referal jarima tizimi ishlamaydi."
        )

    # ---------- 🏆 Top foydalanuvchilar reytingi (kunlik avtomatik yangilanish) ----------
    # Bot ishga tushganda darhol bir marta hisoblanadi (kesh bo'sh
    # qolmasligi uchun), so'ng har 24 soatda qayta hisoblanadi.
    db.refresh_leaderboard_cache()
    if app.job_queue is not None:
        app.job_queue.run_repeating(
            refresh_leaderboard_job, interval=86400, first=86400
        )

    # ---------- 🚫 Bloklangan foydalanuvchilar - ENG BIRINCHI tekshiriladi ----------
    # group=-2 -> hatto majburiy obuna tekshiruvidan ham OLDIN ishga tushadi.
    app.add_handler(MessageHandler(filters.ALL, enforce_block_gate), group=-2)
    app.add_handler(CallbackQueryHandler(enforce_block_gate, pattern=None), group=-2)

    # ---------- 🔒 Majburiy obuna - HAMMA tugmalardan OLDIN tekshiriladi ----------
    # group=-1 -> boshqa har qanday handlerdan (guruh 0, guruh 1, ...) oldin
    # ishga tushadi. Agar foydalanuvchi obuna bo'lmasa, ApplicationHandlerStop
    # orqali qolgan barcha handlerlar ishga tushishi to'xtatiladi.
    app.add_handler(MessageHandler(filters.ALL, enforce_subscription_gate), group=-1)
    app.add_handler(CallbackQueryHandler(enforce_subscription_gate, pattern=None), group=-1)

    # ---------- Buyruqlar ----------
    app.add_handler(CommandHandler("start", start_command))
    app.add_handler(CommandHandler("admin", admin_panel_command))
    app.add_handler(CommandHandler("haqida", haqida_command))
    app.add_handler(CommandHandler("menu", menu_command))
    app.add_handler(CommandHandler("update", update_command))
    app.add_handler(CommandHandler("profil", profil_command))
    app.add_handler(CommandHandler("yordam", yordam_command))
    app.add_handler(CommandHandler("yangiliklar", yangiliklar_command))
    app.add_handler(CommandHandler("saytimiz", saytimiz_command))

    # ---------- 👑 Admin: Pro obuna berish/olib tashlash (musiqa limiti uchun) ----------
    async def grant_pro_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id != ADMIN_ID:
            return
        args = context.args
        if not args or not args[0].isdigit():
            await update.message.reply_text("Foydalanish: /pro <telegram_id>")
            return
        target_id = int(args[0])
        db.set_pro_user(target_id, True)
        await update.message.reply_text(f"✅ <code>{target_id}</code> endi Pro obunachi.", parse_mode="HTML")

    async def revoke_pro_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id != ADMIN_ID:
            return
        args = context.args
        if not args or not args[0].isdigit():
            await update.message.reply_text("Foydalanish: /nopro <telegram_id>")
            return
        target_id = int(args[0])
        db.set_pro_user(target_id, False)
        await update.message.reply_text(f"✅ <code>{target_id}</code> uchun Pro obuna bekor qilindi.", parse_mode="HTML")

    app.add_handler(CommandHandler("pro", grant_pro_command))
    app.add_handler(CommandHandler("nopro", revoke_pro_command))

    # ---------- 🚫 Admin: Foydalanuvchini bloklash/blokdan chiqarish (buyruq orqali ham) ----------
    async def block_user_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id != ADMIN_ID:
            return
        args = context.args
        if not args or not args[0].isdigit():
            await update.message.reply_text("Foydalanish: /block <telegram_id>")
            return
        target_id = int(args[0])
        db.block_user(target_id)
        await update.message.reply_text(f"🚫 <code>{target_id}</code> botdan bloklandi.", parse_mode="HTML")

    async def unblock_user_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id != ADMIN_ID:
            return
        args = context.args
        if not args or not args[0].isdigit():
            await update.message.reply_text("Foydalanish: /unblock <telegram_id>")
            return
        target_id = int(args[0])
        db.unblock_user(target_id)
        await update.message.reply_text(f"✅ <code>{target_id}</code> uchun blok bekor qilindi.", parse_mode="HTML")

    app.add_handler(CommandHandler("block", block_user_command))
    app.add_handler(CommandHandler("unblock", unblock_user_command))

    # ---------- 🎮 Universal "Free Fire menyu" tugmasi ----------
    # keyboards.py dagi har bir inline klaviaturaga avtomatik qo'shiladigan
    # "🎮 Free Fire menyu" tugmasi shu yerda ushlanadi (istalgan bo'limdan
    # bosh menyuga qaytarish uchun).
    app.add_handler(CallbackQueryHandler(on_gotomainmenu_callback, pattern="^gotomainmenu$"))

    # ---------- 🏆 Top foydalanuvchilar ----------
    # keyboards.py dagi har bir inline klaviaturaga "Yordam" tugmasi
    # tagida avtomatik qo'shiladigan ko'k "🏆 Top foydalanuvchilar"
    # tugmasi shu yerda ushlanadi.
    app.add_handler(CallbackQueryHandler(on_top_users_button, pattern="^topusers:show$"))
    # 🔄 Top yangilash (admin paneli tugmasi)
    app.add_handler(MessageHandler(_exact(BTN_TOP_REFRESH), on_top_refresh_button))
    app.add_handler(
        CallbackQueryHandler(on_top_users_tab, pattern="^topusers:(ref|dia|money)$")
    )

    # ---------- 🌐 Til tanlash ----------
    app.add_handler(CallbackQueryHandler(on_language_selected, pattern="^lang:"))

    # ---------- Majburiy obuna tekshiruvi ----------
    app.add_handler(CallbackQueryHandler(check_subscription_callback, pattern="^check_sub$"))
    app.add_handler(CallbackQueryHandler(on_player_type_selected, pattern="^player:"))

    # ---------- 🎮 Nik yaratish (ism -> 20+ nik) ----------
    # MUHIM: bu handler "⬅️ Bosh menyu" (start:back) tugmasini pastdagi
    # umumiy on_start_back_callback handleridan OLDIN ro'yxatdan o'tkazadi -
    # shunda "Nik yaratish" jarayonida (ism so'ralayotganda) orqaga
    # bosilsa, avval jarayon TO'XTATILADI (ConversationHandler.END) va
    # keyin foydalanuvchi /start xabariga qaytariladi. Aks holda jarayon
    # "osilib" qolib, keyingi yuborilgan har qanday matn yana nik nomi
    # sifatida qabul qilinaverardi.
    nick_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_nick_creation, pattern="^ffmenu:nick$")],
        states={
            WAITING_NICK_NAME: [
                CommandHandler("bekor", cancel_nick_creation),
                CallbackQueryHandler(back_to_start_from_nick, pattern="^start:back$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_nick_name),
            ]
        },
        fallbacks=[
            CommandHandler("bekor", cancel_nick_creation),
            CallbackQueryHandler(back_to_start_from_nick, pattern="^start:back$"),
        ],
    )
    app.add_handler(nick_conv)

    # ---------- 🆕 /start rasmi ostidagi 3 ta inline tugma ----------
    app.add_handler(CallbackQueryHandler(on_start_account_callback, pattern="^start:account$"))
    app.add_handler(CallbackQueryHandler(on_start_services_callback, pattern="^start:services$"))
    app.add_handler(CallbackQueryHandler(on_start_back_callback, pattern="^start:back$"))

    # ---------- 🎮 "Nima gap?" bo'limi (Free Fire turnirlar / akkauntlar) ----------
    app.add_handler(CallbackQueryHandler(on_nimagap_open, pattern="^nimagap:menu$"))
    app.add_handler(CallbackQueryHandler(on_nimagap_tournaments_menu, pattern="^nimagap:tournaments$"))
    app.add_handler(CallbackQueryHandler(on_nimagap_accounts, pattern="^nimagap:accounts$"))
    app.add_handler(CallbackQueryHandler(on_fftour_slot_detail, pattern="^fftour:"))

    # ---------- 🔓 Maxsus xizmat (Proxy/Cheat/FF ID) ----------
    hack_ffid_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_hack_ffid, pattern="^hack:ffid$")],
        states={
            WAITING_FF_ID: [
                CommandHandler("bekor", cancel_ffid),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_ff_id),
            ]
        },
        fallbacks=[CommandHandler("bekor", cancel_ffid)],
    )
    app.add_handler(hack_ffid_conv)
    app.add_handler(CallbackQueryHandler(on_hack_proxy, pattern="^hack:proxy$"))
    app.add_handler(CallbackQueryHandler(on_hack_cheat, pattern="^hack:cheat$"))
    app.add_handler(CallbackQueryHandler(on_hack_back, pattern="^hack:back$"))

    # ---------- 📬 Savollar (FAQ) ----------
    faq_conv = ConversationHandler(
        entry_points=[
            MessageHandler(_exact(BTN_FAQ), start_faq),
            CallbackQueryHandler(start_faq_from_callback, pattern="^svc:faq$"),
        ],
        states={
            WAITING_FAQ_QUESTION: [
                CommandHandler("bekor", cancel_faq),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_faq_question),
            ]
        },
        fallbacks=[CommandHandler("bekor", cancel_faq)],
    )
    app.add_handler(faq_conv)

    faq_admin_reply_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_faq_admin_reply, pattern="^faqreply:")],
        states={
            WAITING_FAQ_ADMIN_REPLY: [
                CommandHandler("bekor", cancel_faq_admin_reply),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_faq_admin_reply),
            ]
        },
        fallbacks=[CommandHandler("bekor", cancel_faq_admin_reply)],
    )
    app.add_handler(faq_admin_reply_conv)

    # ---------- 📲 Shaxsiy nastroyka (Pullik / Bepul) ----------
    custom_free_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_custom_free, pattern="^custom:free$")],
        states={
            WAITING_FREE_MODEL: [
                CommandHandler("bekor", cancel_free),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_free_model),
            ]
        },
        fallbacks=[CommandHandler("bekor", cancel_free)],
    )
    app.add_handler(custom_free_conv)

    custom_paid_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_paid_agree, pattern="^paidagree:")],
        states={
            WAITING_PAID_MODEL: [
                CommandHandler("bekor", cancel_paid),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_paid_model),
            ]
        },
        fallbacks=[CommandHandler("bekor", cancel_paid)],
    )
    app.add_handler(custom_paid_conv)

    custom_admin_reply_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_custom_admin_reply, pattern="^customreply:")],
        states={
            WAITING_CUSTOM_ADMIN_REPLY: [
                CommandHandler("bekor", cancel_custom_admin_reply),
                MessageHandler(_any_menu_button_filter(), on_stray_menu_button),
                MessageHandler(
                    (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.Document.ALL)
                    & ~filters.COMMAND,
                    receive_custom_admin_reply,
                ),
            ]
        },
        fallbacks=[CommandHandler("bekor", cancel_custom_admin_reply)],
    )
    app.add_handler(custom_admin_reply_conv)

    app.add_handler(MessageHandler(_exact(BTN_CUSTOM), on_custom_button))
    app.add_handler(CallbackQueryHandler(on_custom_back, pattern="^custom:back$"))
    app.add_handler(CallbackQueryHandler(on_custom_paid, pattern="^custom:paid$"))
    app.add_handler(CallbackQueryHandler(on_paid_tier_selected, pattern="^paidtier:"))
    app.add_handler(CallbackQueryHandler(on_paid_buy_clicked, pattern="^paidbuy:"))

    # ---------- Broadcast conversation (faqat admin) ----------
    broadcast_conv = ConversationHandler(
        entry_points=[MessageHandler(_exact(BTN_BROADCAST), start_broadcast)],
        states={
            WAITING_BROADCAST_CHOICE: [
                CallbackQueryHandler(on_broadcast_type_chosen, pattern="^broadcast_type:"),
            ],
            WAITING_BROADCAST: [
                CommandHandler("bekor", cancel_broadcast),
                MessageHandler(filters.ALL & ~filters.COMMAND, send_broadcast),
            ],
            WAITING_BROADCAST_INLINE_CONTENT: [
                CommandHandler("bekor", cancel_broadcast),
                MessageHandler(filters.ALL & ~filters.COMMAND, receive_broadcast_inline_content),
            ],
            WAITING_BROADCAST_BTN_TEXT: [
                CommandHandler("bekor", cancel_broadcast),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_broadcast_button_text),
            ],
            WAITING_BROADCAST_BTN_URL: [
                CommandHandler("bekor", cancel_broadcast),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_broadcast_button_url),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_broadcast)],
    )
    app.add_handler(broadcast_conv)

    # ---------- 📢 Majburiy obuna boshqaruvi (faqat admin) ----------
    app.add_handler(MessageHandler(_exact(BTN_FORCE_SUB), start_force_sub))
    app.add_handler(CallbackQueryHandler(on_force_sub_remove, pattern="^forcesub:remove:"))
    app.add_handler(CallbackQueryHandler(on_force_sub_close, pattern="^forcesub:close$"))

    force_sub_add_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(start_force_sub_add, pattern="^forcesub:add$")
        ],
        states={
            WAITING_FORCE_SUB_CHANNEL: [
                CommandHandler("bekor", cancel_force_sub_add),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_force_sub_channel),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_force_sub_add)],
    )
    app.add_handler(force_sub_add_conv)

    # ---------- 💎 Almaz yechish minimumi (faqat admin) ----------
    min_withdraw_conv = ConversationHandler(
        entry_points=[MessageHandler(_exact(BTN_MIN_WITHDRAW), start_min_withdraw)],
        states={
            WAITING_MIN_WITHDRAW: [
                CommandHandler("bekor", cancel_min_withdraw),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_min_withdraw_value),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_min_withdraw)],
    )
    app.add_handler(min_withdraw_conv)

    # ---------- Matnlarni tahrirlash conversation (faqat admin) ----------
    edit_texts_conv = ConversationHandler(
        entry_points=[MessageHandler(_exact(BTN_EDIT_TEXTS), start_edit_texts)],
        states={
            WAITING_EDIT_TEXT: [
                CommandHandler("bekor", cancel_edit_text),
                MessageHandler(
                    (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.Document.ALL)
                    & ~filters.COMMAND,
                    receive_new_text,
                ),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_edit_text)],
    )
    app.add_handler(CallbackQueryHandler(choose_text_to_edit, pattern="^edittext:"))
    app.add_handler(edit_texts_conv)

    # ---------- 🗂 Turnir/Akkaunt boshqaruvi (faqat admin) ----------
    app.add_handler(MessageHandler(_exact(BTN_FF_ADMIN_PANEL), on_ff_admin_panel_button))
    app.add_handler(CallbackQueryHandler(on_ff_admin_panel_refresh, pattern="^ffadmin:panel$"))
    app.add_handler(CallbackQueryHandler(on_ff_admin_close, pattern="^ffadmin:close$"))
    app.add_handler(CallbackQueryHandler(on_ff_admin_tour_open, pattern="^ffadmin:tour:"))
    app.add_handler(CallbackQueryHandler(on_ff_admin_tour_delete, pattern="^ffadmin:tourdel:"))
    app.add_handler(CallbackQueryHandler(on_ff_admin_acc_open, pattern="^ffadmin:acc$"))
    app.add_handler(CallbackQueryHandler(on_ff_admin_acc_delete, pattern="^ffadmin:accdel$"))

    fftour_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_ff_admin_tour_add_start, pattern="^ffadmin:touradd:")],
        states={
            WAITING_FFTOUR_CONTENT: [
                CommandHandler("bekor", cancel_fftour),
                MessageHandler((filters.TEXT | filters.PHOTO) & ~filters.COMMAND, receive_fftour_content),
            ],
            WAITING_FFTOUR_CHANNEL: [
                CommandHandler("bekor", cancel_fftour),
                CommandHandler("otkazib_yuborish", skip_fftour_channel),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_fftour_channel),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_fftour)],
    )
    app.add_handler(fftour_conv)

    ffacc_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_ff_admin_acc_add_start, pattern="^ffadmin:accadd$")],
        states={
            WAITING_FFACC_CONTENT: [
                CommandHandler("bekor", cancel_ffacc),
                MessageHandler((filters.TEXT | filters.PHOTO) & ~filters.COMMAND, receive_ffacc_content),
            ],
            WAITING_FFACC_LINK: [
                CommandHandler("bekor", cancel_ffacc),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_ffacc_link),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_ffacc)],
    )
    app.add_handler(ffacc_conv)

    # ---------- ➕ Nastroyka qo'shish (telefon modellariga kontent, faqat admin) ----------
    app.add_handler(MessageHandler(_exact(BTN_NASTROYKA_ADD), on_nastroyka_admin_start))
    app.add_handler(CallbackQueryHandler(on_nastroyka_admin_close, pattern="^nadmin:close$"))
    app.add_handler(CallbackQueryHandler(on_nastroyka_admin_brand, pattern="^nadmin:brand:"))
    app.add_handler(CallbackQueryHandler(on_nastroyka_admin_back_brands, pattern="^nadmin:back_brands$"))
    app.add_handler(CallbackQueryHandler(on_nastroyka_admin_model, pattern="^nadmin:model:"))
    app.add_handler(CallbackQueryHandler(on_nastroyka_admin_back_models, pattern="^nadmin:back_models$"))
    app.add_handler(CallbackQueryHandler(on_nastroyka_admin_delete, pattern="^nadmin:delete$"))

    nastroyka_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_nastroyka_type_selected, pattern="^nadmin:type:")],
        states={
            WAITING_NASTROYKA_CONTENT: [
                CommandHandler("bekor", cancel_nastroyka),
                MessageHandler(
                    (filters.TEXT | filters.PHOTO | filters.VIDEO) & ~filters.COMMAND,
                    receive_nastroyka_content,
                ),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_nastroyka)],
    )
    app.add_handler(nastroyka_conv)

    # ---------- 🛠 Admin buyrug'i (qo'lda pul/almaz berish, faqat admin) ----------
    app.add_handler(MessageHandler(_exact(BTN_ADMIN_CREDIT), on_admin_credit_button))

    # ---------- 🚫 Bloklanganlar (admin paneli: ro'yxat, blokdan chiqarish, qayta bloklash) ----------
    app.add_handler(MessageHandler(_exact(BTN_BLOCKED_USERS), on_blocked_users_button))
    app.add_handler(CallbackQueryHandler(on_blocked_callback, pattern="^blk:"))

    # ---------- ℹ️ Foydalanuvchi haqida (admin paneli: /start sanasi, almaz, pul va h.k.) ----------
    about_user_conv = ConversationHandler(
        entry_points=[MessageHandler(_exact(BTN_ABOUT_USER), on_about_user_button)],
        states={
            WAITING_ABOUT_USER: [
                CommandHandler("bekor", cancel_about_user),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_about_user_id),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_about_user)],
    )
    app.add_handler(about_user_conv)

    admin_credit_flow_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_credit_type_selected, pattern="^credittype:")],
        states={
            WAITING_CREDIT_AMOUNT: [
                CommandHandler("bekor", cancel_credit),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_credit_amount),
            ],
            WAITING_CREDIT_USER_ID: [
                CommandHandler("bekor", cancel_credit),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_credit_user_id),
            ],
            WAITING_BLOCK_USER_ID: [
                CommandHandler("bekor", cancel_credit),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_block_user_id),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_credit)],
    )
    app.add_handler(admin_credit_flow_conv)

    # ---------- 🎁 Hammaga sovg'a (barcha foydalanuvchilarga birdaniga, faqat admin) ----------
    app.add_handler(MessageHandler(_exact(BTN_GIFT_ALL), on_gift_all_button))

    gift_all_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_gift_type_selected, pattern="^giftall:")],
        states={
            WAITING_GIFT_AMOUNT: [
                CommandHandler("bekor", cancel_credit),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_gift_amount),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_credit)],
    )
    app.add_handler(gift_all_conv)
    app.add_handler(CallbackQueryHandler(on_gift_all_confirm, pattern="^giftall_confirm$"))
    app.add_handler(CallbackQueryHandler(on_gift_all_cancel, pattern="^giftall_cancel$"))

    # ---------- ➖ Almazni ayirish (bitta a'zoning hisobidan, faqat admin) ----------
    deduct_diamond_conv = ConversationHandler(
        entry_points=[MessageHandler(_exact(BTN_DEDUCT_DIAMOND), on_deduct_diamond_button)],
        states={
            WAITING_DEDUCT_USERNAME: [
                CommandHandler("bekor", cancel_deduct),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_deduct_username),
            ],
            WAITING_DEDUCT_AMOUNT: [
                CommandHandler("bekor", cancel_deduct),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_deduct_amount),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_deduct)],
    )
    app.add_handler(deduct_diamond_conv)

    # ---------- 🗑 Hammadan almazni yechish (ommaviy, xabarsiz, faqat admin) ----------
    app.add_handler(
        MessageHandler(_exact(BTN_DEDUCT_ALL_DIAMONDS), on_deduct_all_diamonds_button)
    )
    app.add_handler(
        CallbackQueryHandler(on_deduct_all_diamonds_confirm, pattern="^deductall:")
    )

    # ---------- 💎 Almaz yechish ----------
    # 🆕 Eski (350 minimal) Almaz yechish tizimi olib tashlandi. Endi barcha
    # kirish nuqtalari (pastki tugma, "profile:withdraw", "winwd:diamond")
    # yagona, yangilangan "💎 Almaz ishlash" bo'limidagi Almaz yechish
    # oqimiga (handlers/almaz_ishlash.py, minimal 190 💎) yo'naltiriladi.
    app.add_handler(MessageHandler(_exact(BTN_WITHDRAW), on_almaz_withdraw_reply_button))
    app.add_handler(CallbackQueryHandler(on_withdraw_sent_by_admin, pattern="^withdrawsent:"))

    # ---------- Almaz sotib olish (xarid) conversation ----------
    buy_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_buy, pattern="^buy:")],
        states={
            WAITING_ORDER_FF_ID: [
                CommandHandler("bekor", cancel_order),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_order_ff_id),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_order)],
    )
    app.add_handler(buy_conv)

    # ---------- Hisobim to'ldirish (to'lov) conversation ----------
    topup_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_topup_paid, pattern="^topup:paid$")],
        states={
            WAITING_TOPUP_AMOUNT: [
                CommandHandler("bekor", cancel_topup),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_topup_amount),
            ],
            WAITING_TOPUP_RECEIPT: [
                CommandHandler("bekor", cancel_topup),
                MessageHandler(filters.PHOTO & ~filters.COMMAND, receive_topup_receipt),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_topup)],
    )
    app.add_handler(topup_conv)

    # ---------- 💘 Headshot Pro (pullik nastroyka sotib olish) ----------
    app.add_handler(CallbackQueryHandler(on_hspro_intro, pattern="^hspro:start$"))
    app.add_handler(CallbackQueryHandler(on_hspro_prices, pattern="^hspro:prices$"))
    app.add_handler(CallbackQueryHandler(on_hspro_buy, pattern="^hspro:buy$"))
    app.add_handler(CallbackQueryHandler(on_hspro_pay_method, pattern="^hspro:pay:"))
    app.add_handler(CallbackQueryHandler(hspro_approved, pattern="^hspro_ok:"))
    app.add_handler(CallbackQueryHandler(hspro_rejected, pattern="^hspro_no:"))
    # "💎 Almaz ishlash" -> avval 4 tugmali asosiy menyu chiqadi
    app.add_handler(CallbackQueryHandler(on_almaz_menu, pattern="^almazish:start$"))
    # "👥 1. Referal orqali" -> eski referal paneli (yangi kreativ matn bilan)
    app.add_handler(CallbackQueryHandler(on_almaz_dashboard, pattern="^almazish:ref$"))
    # "🎮 2. O'yinlar" -> hozircha bo'sh platsholder (eski Mini O'yinlar
    # tizimiga ulanmaydi)
    app.add_handler(CallbackQueryHandler(on_almaz_games, pattern="^almazish:games$"))
    app.add_handler(CallbackQueryHandler(on_almaz_page1, pattern="^almazish:1$"))
    app.add_handler(CallbackQueryHandler(on_almaz_page2, pattern="^almazish:2$"))
    app.add_handler(CallbackQueryHandler(on_almaz_dashboard, pattern="^almazish:go$"))
    app.add_handler(CallbackQueryHandler(on_almaz_account, pattern="^almazish:account$"))

    # ---------- 💎 Almaz yechish (Referal berish bo'limi ichidan) ----------
    app.add_handler(
        CallbackQueryHandler(on_almaz_withdraw_account, pattern="^almazwd:account$")
    )
    almazwd_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(on_almaz_withdraw_start, pattern="^almazwd:start$"),
            CallbackQueryHandler(on_almaz_withdraw_refcheck, pattern="^almazwd:refcheck$"),
        ],
        states={
            WAITING_ALMAZWD_FF_ID: [
                CommandHandler("bekor", cancel_almazwd),
                CallbackQueryHandler(on_almaz_withdraw_cancel_callback, pattern="^almazwd:cancel$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_almazwd_ff_id),
            ],
            WAITING_ALMAZWD_AMOUNT: [
                CommandHandler("bekor", cancel_almazwd),
                CallbackQueryHandler(on_almaz_withdraw_cancel_callback, pattern="^almazwd:cancel$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_almazwd_amount),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_almazwd)],
    )
    app.add_handler(almazwd_conv)

    hspro_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_hspro_done, pattern="^hspro:done:")],
        states={
            WAITING_HSPRO_AMOUNT: [
                CommandHandler("bekor", cancel_hspro),
                CallbackQueryHandler(cancel_hspro, pattern="^hspro:cancel$"),
                CallbackQueryHandler(cancel_hspro, pattern="^hspro:buy$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_hspro_amount),
            ],
            WAITING_HSPRO_RECEIPT: [
                CommandHandler("bekor", cancel_hspro),
                CallbackQueryHandler(cancel_hspro, pattern="^hspro:cancel$"),
                MessageHandler(
                    (filters.PHOTO | filters.VIDEO) & ~filters.COMMAND, receive_hspro_receipt
                ),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_hspro)],
    )
    app.add_handler(hspro_conv)

    # ---------- 🔧 Headshot Pro - "Nastroykani olish" (telefon modeli so'rash) ----------
    hspro_getset_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_hspro_get_settings_start, pattern="^hspro_getset:")],
        states={
            WAITING_HSPRO_PHONE_MODEL: [
                CommandHandler("bekor", cancel_hspro_get_settings),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_hspro_phone_model),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_hspro_get_settings)],
    )
    app.add_handler(hspro_getset_conv)

    # ---------- 🔥 Oddiy Rasm (nom/matn -> uslub tanlash -> natija) ----------
    oddiy_rasm_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_oddiy_rasm_start, pattern="^rasm:oddiy$")],
        states={
            WAITING_ODDIY_TEXT: [
                CommandHandler("bekor", cancel_oddiy),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_oddiy_text),
            ],
        },
        fallbacks=[
            CommandHandler("bekor", cancel_oddiy),
            CallbackQueryHandler(on_rasm_back, pattern="^rasm:back$"),
        ],
    )
    app.add_handler(oddiy_rasm_conv)
    app.add_handler(CallbackQueryHandler(on_oddiy_style_selected, pattern="^oddiyrasm:"))

    # ---------- 💎 Maxsus Rasm (nom -> tavsif -> adminga yuboriladi) ----------
    maxsus_rasm_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_maxsus_rasm_start, pattern="^rasm:maxsus$")],
        states={
            WAITING_MAXSUS_NAME: [
                CommandHandler("bekor", cancel_maxsus),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_maxsus_name),
            ],
            WAITING_MAXSUS_DESC: [
                CommandHandler("bekor", cancel_maxsus),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_maxsus_desc),
            ],
        },
        fallbacks=[
            CommandHandler("bekor", cancel_maxsus),
            CallbackQueryHandler(on_rasm_back, pattern="^rasm:back$"),
        ],
    )
    app.add_handler(maxsus_rasm_conv)

    # ---------- 🖼️ Rasm Yasash bosh menyusi + orqaga (mustaqil) ----------
    app.add_handler(MessageHandler(_exact(BTN_MAIN_RASM), on_rasm_button))
    app.add_handler(CallbackQueryHandler(on_rasm_back, pattern="^rasm:back$"))

    # ---------- 🎬 Video Yasash (faqat pullik, kamida 30 000 so'm) ----------
    video_conv = ConversationHandler(
        entry_points=[
            MessageHandler(_exact(BTN_MAIN_VIDEO), on_video_button),
            CallbackQueryHandler(on_video_button_from_services, pattern="^svcall:video$"),
        ],
        states={
            WAITING_VIDEO_PROMPT: [
                CommandHandler("bekor", cancel_video),
                CallbackQueryHandler(on_video_cancel_inline, pattern="^video:cancel$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_video_prompt),
            ],
        },
        fallbacks=[
            CommandHandler("bekor", cancel_video),
            CallbackQueryHandler(on_video_cancel_inline, pattern="^video:cancel$"),
        ],
    )
    app.add_handler(video_conv)

    # ---------- 🎵 Musiqa yaratish ----------
    app.add_handler(MessageHandler(_exact(BTN_MAIN_MUSIC), on_music_create_button))
    app.add_handler(CallbackQueryHandler(on_music_cancel, pattern="^music:cancel$"))

    music_prompt_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_music_genre_selected, pattern="^music:genre:")],
        states={
            WAITING_MUSIC_PROMPT: [
                CommandHandler("bekor", cancel_music_prompt),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_music_prompt),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_music_prompt)],
    )
    app.add_handler(music_prompt_conv)

    app.add_handler(CallbackQueryHandler(on_music_back_to_genre, pattern="^music:back_genre$"))
    app.add_handler(CallbackQueryHandler(on_music_lang_selected, pattern="^music:lang:"))
    app.add_handler(CallbackQueryHandler(on_music_back_to_lang, pattern="^music:back_lang:"))
    app.add_handler(CallbackQueryHandler(on_music_prepare, pattern="^music:prepare:"))

    music_admin_reply_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_music_admin_reply, pattern="^musicsend:")],
        states={
            WAITING_MUSIC_ADMIN_REPLY: [
                CommandHandler("bekor", cancel_music_admin_reply),
                MessageHandler(
                    (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.AUDIO
                     | filters.VOICE | filters.Document.ALL)
                    & ~filters.COMMAND,
                    receive_music_admin_reply,
                ),
            ]
        },
        fallbacks=[CommandHandler("bekor", cancel_music_admin_reply)],
    )
    app.add_handler(music_admin_reply_conv)

    # ---------- Reply tugmalar ----------
    app.add_handler(MessageHandler(_exact(BTN_HELP), on_help_button))
    app.add_handler(MessageHandler(_exact(BTN_SETTINGS), on_settings_button))
    app.add_handler(MessageHandler(_exact(BTN_NICKS), on_nicks_button))
    app.add_handler(MessageHandler(_exact(BTN_TABLET), on_tablet_button))
    app.add_handler(MessageHandler(_exact(BTN_GUIDES), on_guides_button))
    app.add_handler(MessageHandler(_exact(BTN_WEBSITE), on_turnirlar_button))
    app.add_handler(MessageHandler(_exact(BTN_FF2017), on_ff2017_button))
    app.add_handler(MessageHandler(_exact(BTN_NEWS), on_news_button))
    app.add_handler(MessageHandler(_exact(BTN_MUSIC), on_music_button))
    app.add_handler(MessageHandler(_exact(BTN_QUIZ), on_quiz_button))
    app.add_handler(CallbackQueryHandler(on_quiz_begin, pattern="^quiz_begin$"))
    app.add_handler(CallbackQueryHandler(on_quiz_answer, pattern="^quiz:"))
    app.add_handler(MessageHandler(_exact(BTN_HACK), on_hack_button))
    app.add_handler(MessageHandler(_exact(BTN_STATS), on_stats_button))
    app.add_handler(MessageHandler(_exact(BTN_DIAMONDS), on_diamonds_button))
    app.add_handler(MessageHandler(_exact(BTN_ACCOUNT), on_account_button))

    # ---------- 🏆 Free Fire Turnirlar (ochiq ro'yxat) ----------
    app.add_handler(CallbackQueryHandler(on_turnir_open, pattern="^turnir:open:"))
    app.add_handler(CallbackQueryHandler(on_turnir_nav, pattern="^turnir:nav:"))
    app.add_handler(CallbackQueryHandler(on_turnir_back_list, pattern="^turnir:list$"))
    app.add_handler(CallbackQueryHandler(on_turniradmin_delete, pattern="^turniradmin:del:"))

    turniradmin_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_turniradmin_add_start, pattern="^turniradmin:add$")],
        states={
            WAITING_TURNIR_DAY: [
                CommandHandler("bekor", cancel_turnir_add),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_turnir_day),
            ],
            WAITING_TURNIR_TITLE: [
                CommandHandler("bekor", cancel_turnir_add),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_turnir_title),
            ],
            WAITING_TURNIR_FORMAT: [
                CommandHandler("bekor", cancel_turnir_add),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_turnir_format),
            ],
            WAITING_TURNIR_TIME: [
                CommandHandler("bekor", cancel_turnir_add),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_turnir_time),
            ],
            WAITING_TURNIR_NOTE: [
                CommandHandler("bekor", cancel_turnir_add),
                CommandHandler("otkazib_yuborish", skip_turnir_note),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_turnir_note),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_turnir_add)],
    )
    app.add_handler(turniradmin_conv)

    # ---------- Inline callbacklar: Nastroykalar (telefon) ----------
    app.add_handler(CallbackQueryHandler(on_brand_selected, pattern="^brand:"))
    app.add_handler(CallbackQueryHandler(on_back_to_brands, pattern="^back_to_brands$"))
    app.add_handler(CallbackQueryHandler(on_model_selected, pattern="^model:"))

    # ---------- Inline callbacklar: Planshet nastroykalari ----------
    app.add_handler(CallbackQueryHandler(on_tablet_brand_selected, pattern="^tbrand:"))
    app.add_handler(CallbackQueryHandler(on_back_to_tablet_brands, pattern="^back_to_tbrands$"))
    app.add_handler(CallbackQueryHandler(on_tablet_model_selected, pattern="^tmodel:"))

    # ---------- Inline callbacklar: Niklar ----------
    app.add_handler(CallbackQueryHandler(on_nick_category, pattern="^nick:"))
    app.add_handler(CallbackQueryHandler(on_back_to_nicks, pattern="^back_to_nicks$"))

    # ---------- Inline callbacklar: Qo'llanmalar ----------
    app.add_handler(CallbackQueryHandler(on_guide_selected, pattern="^guide:"))
    app.add_handler(CallbackQueryHandler(on_back_to_guides, pattern="^back_to_guides$"))

    # ---------- Inline callbacklar: Almaz sotib olish ----------
    app.add_handler(CallbackQueryHandler(on_diamonds_admin, pattern="^dia:admin$"))
    app.add_handler(CallbackQueryHandler(on_diamonds_bot, pattern="^dia:bot$"))
    app.add_handler(CallbackQueryHandler(on_diamonds_back, pattern="^dia:back$"))
    app.add_handler(CallbackQueryHandler(on_package_selected, pattern="^pkg:"))
    app.add_handler(CallbackQueryHandler(order_sent_by_admin, pattern="^order_sent:"))
    app.add_handler(CallbackQueryHandler(go_to_account_hint, pattern="^go_account$"))

    # ---------- Inline callbacklar: Hisobim ----------
    app.add_handler(CallbackQueryHandler(on_account_admin, pattern="^acc:admin$"))
    app.add_handler(CallbackQueryHandler(on_account_card, pattern="^acc:card$"))
    app.add_handler(CallbackQueryHandler(on_account_bonus, pattern="^acc:bonus$"))
    app.add_handler(CallbackQueryHandler(on_account_back, pattern="^acc:back$"))
    app.add_handler(CallbackQueryHandler(topup_approved, pattern="^topup_ok:"))
    app.add_handler(CallbackQueryHandler(topup_rejected, pattern="^topup_no:"))

    # ============================================================================
    # 🆕 Yangi bosh menyu (faqat 4 ta tugma): 🎮 Free Fire / 💎 Almaz olish /
    # 🛠️ Xizmatlar / 👤 Profil
    # ============================================================================

    # ---------- 🎮 Free Fire (reply tugma + inline bo'limlar) ----------
    app.add_handler(MessageHandler(_exact(BTN_MAIN_FF), on_ff_main_button))
    app.add_handler(CallbackQueryHandler(on_back_to_ff, pattern="^back_to_ff$"))
    app.add_handler(CallbackQueryHandler(on_ff_phone, pattern="^ffmenu:phone$"))
    app.add_handler(CallbackQueryHandler(on_ff_tablet, pattern="^ffmenu:tablet$"))
    app.add_handler(CallbackQueryHandler(on_ff_pc, pattern="^ffmenu:pc$"))

    # ---------- 💻 PC nastroyka (20 ta model) ----------
    app.add_handler(CallbackQueryHandler(on_pc_model_selected, pattern="^pc:"))
    app.add_handler(CallbackQueryHandler(on_back_to_pc, pattern="^back_to_pc$"))

    # ---------- 💎 Almaz olish (reply tugma - eski Almaz sotib olish oqimi qayta ishlatiladi) ----------
    app.add_handler(MessageHandler(_exact(BTN_MAIN_DIAMONDS), on_diamonds_button))

    # ---------- 🛠️ Xizmatlar (reply tugma + inline bo'limlar) ----------
    app.add_handler(MessageHandler(_exact(BTN_MAIN_SERVICES), on_services_button))
    app.add_handler(CallbackQueryHandler(on_back_to_services, pattern="^back_to_services$"))
    app.add_handler(CallbackQueryHandler(on_svc_bonus, pattern="^svc:bonus$"))
    app.add_handler(CallbackQueryHandler(on_svc_pay, pattern="^svc:pay$"))
    app.add_handler(CallbackQueryHandler(on_svc_guides, pattern="^svc:guides$"))
    app.add_handler(CallbackQueryHandler(on_svc_news, pattern="^svc:news$"))
    app.add_handler(CallbackQueryHandler(on_svc_other, pattern="^svc:other$"))
    app.add_handler(CallbackQueryHandler(on_back_to_services_other, pattern="^back_to_svcother$"))
    app.add_handler(CallbackQueryHandler(on_svcother_help, pattern="^svcother:help$"))
    app.add_handler(CallbackQueryHandler(on_svcother_website, pattern="^svcother:website$"))
    app.add_handler(CallbackQueryHandler(on_svcother_music, pattern="^svcother:music$"))
    app.add_handler(CallbackQueryHandler(on_svcother_hack, pattern="^svcother:hack$"))
    app.add_handler(CallbackQueryHandler(on_svcother_custom, pattern="^svcother:custom$"))
    app.add_handler(CallbackQueryHandler(on_svcother_ff2017, pattern="^svcother:ff2017$"))

    # ---------- 🎁 Bonuslar (Xizmatlar ichida - Tekin almaz + Kunlik bonus) ----------
    app.add_handler(CallbackQueryHandler(on_quiz_button_callback, pattern="^svcbonus:quiz$"))
    app.add_handler(CallbackQueryHandler(on_account_bonus, pattern="^svcbonus:daily$"))

    # ---------- 👤 Profil (reply tugma + inline: Hisobim / Almaz yechish) ----------
    app.add_handler(MessageHandler(_exact(BTN_MAIN_PROFILE), on_profile_button))
    app.add_handler(CallbackQueryHandler(on_profile_account, pattern="^profile:account$"))
    app.add_handler(CallbackQueryHandler(on_almaz_withdraw_account, pattern="^profile:withdraw$"))

    # ============================================================================
    # 🆕 Yangi asosiy menyu (6 tugma, 2 ustunda):
    # 💎 Almaz olish | 🛍 Xizmatlar
    # ⚙️ Nastroykalar | 🎉 Free Fire Niklar
    # 💰 To'lov usullari | 📬 Savollar (FAQ)
    # (📬 Savollar (FAQ) tugmasi matni eski BTN_FAQ bilan bir xil, shu sabab
    # yuqoridagi faq_conv avtomatik ishlaydi - qo'shimcha handler shart emas)
    # ============================================================================

    # ---------- 💎 Almaz olish ----------
    app.add_handler(MessageHandler(_exact(BTN_M2_DIAMONDS), on_m2_diamonds_button))
    app.add_handler(CallbackQueryHandler(on_diaget_free, pattern="^diaget:free$"))
    app.add_handler(CallbackQueryHandler(on_diaget_buy, pattern="^diaget:buy$"))

    # ---------- ⚙️ Nastroykalar ----------
    app.add_handler(MessageHandler(_exact(BTN_M2_SETTINGS), on_m2_settings_button))
    app.add_handler(CallbackQueryHandler(on_newset_back, pattern="^newset:back$"))
    app.add_handler(CallbackQueryHandler(on_newset_premium, pattern="^newset:premium$"))
    # Telefon/Planshet/PC nastroykalari - mavjud Free Fire menyusidagi funksiyalar
    # qayta ishlatiladi (kod takrorlanmasligi uchun)
    app.add_handler(CallbackQueryHandler(on_ff_phone, pattern="^newset:phone$"))
    app.add_handler(CallbackQueryHandler(on_ff_tablet, pattern="^newset:tablet$"))
    app.add_handler(CallbackQueryHandler(on_ff_pc, pattern="^newset:pc$"))

    # ---------- 🎉 Free Fire Niklar ----------
    app.add_handler(MessageHandler(_exact(BTN_M2_NICKS), on_m2_nicks_button))
    app.add_handler(CallbackQueryHandler(on_newnick_back, pattern="^newnick:back$"))
    app.add_handler(
        CallbackQueryHandler(
            on_newnick_category,
            pattern="^newnick:(gamer|super|pro|top|chiroyli)$",
        )
    )
    # "🛠 Nik Yasash" tugmasi mavjud "ffmenu:nick" conversation'ini ishga tushiradi
    # (yuqorida nick_conv allaqachon ro'yxatdan o'tgan)

    # ---------- 🛍 Xizmatlar ----------
    app.add_handler(MessageHandler(_exact(BTN_M2_SERVICES), on_m2_services_button))
    app.add_handler(CallbackQueryHandler(on_newsvc_back, pattern="^newsvc:back$"))
    app.add_handler(
        CallbackQueryHandler(
            on_newsvc_item,
            pattern="^newsvc:(ff2017|tournament|proxy|ffidm|cheat|news|music)$",
        )
    )

    # ---------- 💰 To'lov usullari ----------
    app.add_handler(MessageHandler(_exact(BTN_M2_PAYMENTS), on_m2_payments_button))
    app.add_handler(CallbackQueryHandler(on_pay_back, pattern="^pay:back$"))
    app.add_handler(CallbackQueryHandler(on_pay_admin, pattern="^pay:admin$"))
    app.add_handler(CallbackQueryHandler(on_pay_card, pattern="^pay:card$"))

    # ---------- 🎁 Sovg'alar (yangi bosh menyu tugmasi) ----------
    app.add_handler(MessageHandler(_exact(BTN_GIFTS), on_gifts_button))
    app.add_handler(CallbackQueryHandler(on_gift_free_diamond, pattern="^gift:free_diamond$"))
    app.add_handler(CallbackQueryHandler(on_gift_money_bonus, pattern="^gift:money_bonus$"))
    app.add_handler(CallbackQueryHandler(on_gift_diamond_bonus, pattern="^gift:diamond_bonus$"))

    # ---------- 🛒 Free Fire Do'koni (yangi bosh menyu tugmasi) ----------
    app.add_handler(MessageHandler(_exact(BTN_STORE), on_store_button))
    app.add_handler(CallbackQueryHandler(on_store_back, pattern="^store:back$"))
    app.add_handler(CallbackQueryHandler(on_store_item_selected, pattern="^storeitem:"))
    app.add_handler(CallbackQueryHandler(store_order_sent_by_admin, pattern="^store_sent:"))

    store_buy_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_store_buy, pattern="^storebuy:")],
        states={
            WAITING_STORE_FF_ID: [
                CommandHandler("bekor", cancel_store_order),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_store_ff_id),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_store_order)],
    )
    app.add_handler(store_buy_conv)

    # ---------- 🎁 Giftlar (yangi bosh menyu tugmasi - o'yin ichidagi gift buyurtmalari) ----------
    app.add_handler(MessageHandler(_exact(BTN_GIFT_ORDER), on_gift_order_button))

    gift_order_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(
                on_gift_order_type_selected,
                pattern="^giftorder:(character|emote|gunskin|evogun|bundle)$",
            )
        ],
        states={
            WAITING_GIFT_ORDER_ITEM: [
                CommandHandler("bekor", cancel_gift_order),
                CallbackQueryHandler(on_gift_order_back, pattern="^giftorder:back$"),
                MessageHandler(
                    (filters.TEXT | filters.PHOTO) & ~filters.COMMAND,
                    receive_gift_order_item,
                ),
            ],
        },
        fallbacks=[
            CommandHandler("bekor", cancel_gift_order),
            CallbackQueryHandler(on_gift_order_back, pattern="^giftorder:back$"),
        ],
    )
    app.add_handler(gift_order_conv)
    app.add_handler(CallbackQueryHandler(on_gift_order_back, pattern="^giftorder:back$"))

    gift_order_admin_reply_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_gift_order_admin_reply, pattern="^giftreply:")],
        states={
            WAITING_GIFT_ORDER_ADMIN_REPLY: [
                CommandHandler("bekor", cancel_gift_order_admin_reply),
                MessageHandler(
                    (filters.TEXT | filters.PHOTO | filters.VIDEO | filters.Document.ALL)
                    & ~filters.COMMAND,
                    receive_gift_order_admin_reply,
                ),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_gift_order_admin_reply)],
    )
    app.add_handler(gift_order_admin_reply_conv)

    # ---------- 🏆 Yutiqni chiqarish (yangi bosh menyu tugmasi - Pul/Almaz) ----------
    app.add_handler(MessageHandler(_exact(BTN_WITHDRAW_WIN), on_withdraw_win_button))
    app.add_handler(CallbackQueryHandler(on_withdraw_win_back, pattern="^winwd:back$"))
    app.add_handler(CallbackQueryHandler(on_withdraw_win_cash_noop, pattern="^winwd:noop$"))
    # 💎 Almaz tanlansa, yangilangan "💎 Almaz yechish" oqimi ishlatiladi
    app.add_handler(CallbackQueryHandler(on_almaz_withdraw_account, pattern="^winwd:diamond$"))

    withdraw_win_cash_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_withdraw_win_cash, pattern="^winwd:cash$")],
        states={
            WAITING_WITHDRAW_CASH_AMOUNT: [
                CommandHandler("bekor", cancel_withdraw_cash),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_withdraw_cash_amount),
            ],
        },
        fallbacks=[CommandHandler("bekor", cancel_withdraw_cash)],
    )
    app.add_handler(withdraw_win_cash_conv)

    # ---------- 🎮 Mini O'yinlar ----------
    app.add_handler(MessageHandler(_exact(BTN_MINI_GAMES), on_games_button))
    app.add_handler(MessageHandler(_exact(BTN_MY_ACCOUNT), on_my_account_button))
    app.add_handler(CallbackQueryHandler(on_myacc_pay_button, pattern="^myacc:pay$"))

    # 👑 Pro obuna
    app.add_handler(MessageHandler(_exact(BTN_PRO_SUB), on_pro_sub_button))
    app.add_handler(CallbackQueryHandler(on_prosub_buy, pattern="^prosub:buy$"))

    # 👑 Pro obuna FAOLLASHGANDAN KEYINGI maxsus bo'lim (qizil tugmalar)
    app.add_handler(CallbackQueryHandler(on_prosec_back, pattern="^prosec:back$"))
    app.add_handler(CallbackQueryHandler(on_prosec_superik, pattern="^prosec:superik$"))
    app.add_handler(CallbackQueryHandler(on_prosec_sirli, pattern="^prosec:sirli$"))
    app.add_handler(CallbackQueryHandler(on_prosec_mukofot, pattern="^prosec:mukofot$"))

    pro_brazilian_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_prosec_brazilian, pattern="^prosec:brazilian$")],
        states={
            WAITING_PRO_BRAZIL_MODEL: [
                CommandHandler("bekor", cancel_pro_brazilian),
                CallbackQueryHandler(on_prosec_back, pattern="^prosec:back$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_pro_brazilian_model),
            ],
        },
        fallbacks=[
            CommandHandler("bekor", cancel_pro_brazilian),
            CallbackQueryHandler(on_prosec_back, pattern="^prosec:back$"),
        ],
    )
    app.add_handler(pro_brazilian_conv)

    pro_aivideo_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_prosec_aivideo, pattern="^prosec:aivideo$")],
        states={
            WAITING_PRO_VIDEO_PROMPT: [
                CommandHandler("bekor", cancel_pro_aivideo),
                CallbackQueryHandler(on_prosec_back, pattern="^prosec:back$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_pro_video_prompt),
            ],
        },
        fallbacks=[
            CommandHandler("bekor", cancel_pro_aivideo),
            CallbackQueryHandler(on_prosec_back, pattern="^prosec:back$"),
        ],
    )
    app.add_handler(pro_aivideo_conv)

    pro_airasm_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(on_prosec_airasm, pattern="^prosec:airasm$")],
        states={
            WAITING_PRO_RASM_PROMPT: [
                CommandHandler("bekor", cancel_pro_airasm),
                CallbackQueryHandler(on_prosec_back, pattern="^prosec:back$"),
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_pro_rasm_prompt),
            ],
        },
        fallbacks=[
            CommandHandler("bekor", cancel_pro_airasm),
            CallbackQueryHandler(on_prosec_back, pattern="^prosec:back$"),
        ],
    )
    app.add_handler(pro_airasm_conv)

    # 📢 Buyurtmalar kanali - bosilganda kanalga o'tish tugmasi chiqadi
    app.add_handler(MessageHandler(_exact(BTN_ORDERS_CHANNEL), on_orders_channel_button))

    # 🔙 Universal "Orqaga" - istalgan bo'limdan bosh menyuga qaytaradi
    app.add_handler(MessageHandler(_exact(BTN_BACK), on_back_to_main))

    # ---------- 🆕 "🛠️ Barcha xizmatlar" ro'yxatidagi umumiy handler ----------
    # MUHIM: bu handler video_conv'dan (va boshqa aniqroq "^svcall:video$"
    # pattern'idan) KEYIN qo'shilishi SHART - aks holda video uchun maxsus
    # ConversationHandler entry_point'i ishlamay qolib, holat saqlanmaydi.
    app.add_handler(CallbackQueryHandler(on_all_services_item, pattern="^svcall:"))
    # 🎮 Mini O'yinlar (qiyin darajadagi 10 ta Free Fire o'yini)
    app.add_handler(CallbackQueryHandler(on_hard_games_root_callback, pattern="^hg:"))
    # 🟢 Oson O'yinlar (20 ta yengil o'yin)
    app.add_handler(CallbackQueryHandler(on_easy_games_callback, pattern="^eg:"))
    # 💣 Portlovchi almaz (4 ta tavakkal o'yini)
    app.add_handler(CallbackQueryHandler(on_risk_games_callback, pattern="^rg:"))
    # "Sonni top" o'yinida faqat raqamli xabarlar shu yerda ushlanadi; boshqa
    # conversationlar (masalan to'lov, FF ID) o'z holatida ustuvor bo'lib
    # qoladi, chunki bu handler ular ro'yxatdan o'tgandan KEYIN qo'shilgan.
    app.add_handler(MessageHandler(filters.Regex(r"^\d+$") & ~filters.COMMAND, receive_number_guess))

    # ---------- Statistika uchun umumiy loglash (barcha xabarlar) ----------
    app.add_handler(MessageHandler(filters.ALL, log_all_messages), group=1)
    # ---------- Inline tugma bosilganda ham menyu avtomatik yangilanishi ----------
    app.add_handler(CallbackQueryHandler(log_all_callbacks, pattern=None), group=1)

    return app


def main():
    app = build_application()
    logger.info("Bot ishga tushdi...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
